class Account:
  def __init__(self, account_number, pin, balance=0):
      self.account_number = account_number
      self.pin = pin
      self.balance = balance

  def check_balance(self):
      return self.balance

  def deposit(self, amount):
      if amount > 0:
          self.balance += amount
          return True
      return False

  def withdraw(self, amount):
      if 0 < amount <= self.balance:
          self.balance -= amount
          return True
      return False


class ATM:
  def __init__(self):
      self.accounts = {}
      self.current_account = None

  def create_account(self, account_number, pin, balance=0):
      if account_number not in self.accounts:
          self.accounts[account_number] = Account(account_number, pin, balance)
          return True
      return False

  def authenticate(self, account_number, pin):
      account = self.accounts.get(account_number)
      if account and account.pin == pin:
          self.current_account = account
          return True
      return False

  def logout(self):
      self.current_account = None

  def check_balance(self):
      if self.current_account:
          return self.current_account.check_balance()
      return None

  def deposit(self, amount):
      if self.current_account:
          return self.current_account.deposit(amount)
      return False

  def withdraw(self, amount):
      if self.current_account:
          return self.current_account.withdraw(amount)
      return False


def main():
  atm = ATM()
  while True:
      print("\nWelcome to the ATM")
      print("1. Create Account")
      print("2. Login")
      print("3. Exit")
      choice = input("Choose an option: ")

      if choice == '1':
          account_number = input("Enter account number: ")
          pin = input("Enter PIN: ")
          initial_balance = float(input("Enter initial balance: "))
          if atm.create_account(account_number, pin, initial_balance):
              print("Account created successfully.")
          else:
              print("Account already exists.")
      elif choice == '2':
          account_number = input("Enter account number: ")
          pin = input("Enter PIN: ")
          if atm.authenticate(account_number, pin):
              while True:
                  print("\n1. Check Balance")
                  print("2. Deposit")
                  print("3. Withdraw")
                  print("4. Logout")
                  option = input("Choose an option: ")

                  if option == '1':
                      balance = atm.check_balance()
                      print(f"Your balance is: {balance}")
                  elif option == '2':
                      amount = float(input("Enter amount to deposit: "))
                      if atm.deposit(amount):
                          print("Deposit successful.")
                      else:
                          print("Deposit failed.")
                  elif option == '3':
                      amount = float(input("Enter amount to withdraw: "))
                      if atm.withdraw(amount):
                          print("Withdrawal successful.")
                      else:
                          print("Withdrawal failed.")
                  elif option == '4':
                      atm.logout()
                      print("Logged out successfully.")
                      break
                  else:
                      print("Invalid option.")
          else:
              print("Authentication failed.")
      elif choice == '3':
          print("Thank you for using the ATM. Goodbye!")
          break
      else:
          print("Invalid option. Please try again.")

if __name__ == "__main__":
  main()
